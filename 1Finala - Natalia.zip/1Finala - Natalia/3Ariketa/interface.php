<?php
interface Datuak_Kudeatu
{
    public function bilatuPertsona($id);
}
?>